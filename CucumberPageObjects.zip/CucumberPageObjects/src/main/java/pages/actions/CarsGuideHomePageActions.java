package pages.actions;


import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import pages.locators.CarsSearchPageLocators;
import utilities.SeleniumDriver;

public class CarsGuideHomePageActions {

	CarsSearchPageLocators carssearchpagelocators = null;
	
	public CarsGuideHomePageActions() {
		this.carssearchpagelocators = new CarsSearchPageLocators();
		PageFactory.initElements(SeleniumDriver.getDriver(), carssearchpagelocators);
	}
	
	public void selectCarMake(String carBrand) {
		Select selectCarMaker = new Select(carssearchpagelocators.carMakeDropDown);
		selectCarMaker.selectByVisibleText(carBrand);
		
	}

	public void ClickOnCarMakeDropDown() {
		carssearchpagelocators.carMakeDropDown.click();
		
	}
	
	public void selectCarModel(String carModel) {
		Select selectCarMaker = new Select(carssearchpagelocators.selectModelDropDown);
		selectCarMaker.selectByVisibleText(carModel);
		
	}
	
	public void ClickOnCarModelDropDown() {
		carssearchpagelocators.selectModelDropDown.click();
		
	}
	
	
	public void clickOnShowMeCars() {
			carssearchpagelocators.showMeCarsButton.click();
			
	}
	
	public void ClickonUsed() {
		
	}
}
