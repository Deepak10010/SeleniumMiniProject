package pages.locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CarsSearchPageLocators {

	@FindBy(how=How.XPATH, using="//select[@data-gtm-category='search drivers']")
	public WebElement carMakeDropDown;
	
	@FindBy(how=How.XPATH, using="//button[@class='uhf-button-purple-border']")
	public WebElement sellMyCarButton;
	
	@FindBy(how=How.XPATH, using="//select[@id='models']")
	public WebElement selectModelDropDown;
	
	@FindBy(how=How.XPATH, using="//button[@id='search-submit']")
	public WebElement showMeCarsButton;
	
}
