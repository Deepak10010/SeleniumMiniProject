package steps;

import org.testng.Assert;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.actions.CarsGuideHomePageActions;
import utilities.SeleniumDriver;

public class SearchCarsStep {
	
	CarsGuideHomePageActions carsguidehomepageactions = new CarsGuideHomePageActions();
	
	@Given("^I am on the home page \"([^\"]*)\" of Cars Guide website$")
	public void i_am_on_the_home_page_of_Cars_Guide_website(String WebsiteURL) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		SeleniumDriver.openPage(WebsiteURL);
	}

	@When("^click on \"([^\"]*)\" dropdown$")
	public void click_on_dropdown(String carMake) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		   carsguidehomepageactions.ClickOnCarMakeDropDown();
	}

	@And("^select Car brand as \"([^\"]*)\"$")
	public void select_Car_brand_as(String carBrand) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		carsguidehomepageactions.selectCarMake(carBrand);
	}

	@And("^select on \"([^\"]*)\" dropdown$")
	public void click_on_Model(String CarMod) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    carsguidehomepageactions.ClickOnCarModelDropDown();
	}

	
	@And("^select Car Model as \"([^\"]*)\"$")
	public void select_Model_as(String carModel) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    carsguidehomepageactions.selectCarModel(carModel);
	}
	
	@And("^click on \"([^\"]*)\" button$")
	public void click_on_button(String button) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    carsguidehomepageactions.clickOnShowMeCars();
	}
	
	@Then("^the page title should be \"([^\"]*)\"$")
	public void the_page_title_should_be(String expectedTitle) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  String actual_title =  SeleniumDriver.getDriver().getTitle();
	  Assert.assertEquals(actual_title, expectedTitle);
	}
	

}